# Project Brief: NotableBIT Technology Studio

## 1. Project Overview
NotableBIT is a founder-led technology studio building products, platforms, media, and strategic systems for the AI era. This project involves the creation of a premium, cohesive digital presence that positions NotableBIT as the central vehicle behind an aligned ecosystem of tech initiatives, consulting services, and community-building work.

## 2. Core Positioning
*   **Mission:** To help builders and organizations move from abstract ideas to operational execution.
*   **Key Pillars:**
    *   **Software Engineering Depth:** Hardened, production-ready systems.
    *   **Product Strategy:** Moving from founder intent to structured specifications.
    *   **AI Workflow Thinking:** Human-in-the-loop AI implementation.
    *   **Black Tech Excellence:** Visibility and ownership for Black builders and technologists.

## 3. The Ecosystem (Aligned Vehicles)
*   **HindSite:** Workflow intelligence tool for builders (Alpha/Waitlist).
*   **BitVoices Network:** Platform and media network amplifying Black excellence in tech.
*   **BIT Voices Podcast:** Editorial conversations with industry leaders.
*   **Strategic Services:** Fractional CTO, AI workflow strategy, and MVP planning.

## 4. Design & Visual Identity
### Visual Direction
*   **Aesthetic:** Premium "Dark Studio" / Cinematic Technology.
*   **Palette:** Deep Black, Midnight Navy, Charcoal, Electric Blue (Primary), Warm Amber (Accents).
*   **Typography:** Bold modern sans-serif (Inter) with Monospace accents for technical details.
*   **Motifs:** Connected network nodes, orbital maps, timeline traces, and premium card layouts with subtle glows.

### User Experience Goals
*   **Strategic Hierarchy:** Use strong editorial layouts to communicate depth over volume.
*   **Founder-Led Tone:** Anchored by B Donald Harris’s leadership without being a personal portfolio.
*   **Clarity:** Generous whitespace and technical precision in every UI element.

## 5. Site Structure & Navigation
*   **Home:** Strategic ecosystem map and mission overview.
*   **Studio:** Methodology ("How We Think" / "How We Build").
*   **Products:** Showcase of HindSite and BitVoices.
*   **Consulting:** Selective advisory and fractional leadership.
*   **Media:** Podcast and community storytelling.
*   **About:** Origin story, core values, and founder background.
*   **Contact:** High-intent inquiry system.

## 6. Technical Requirements
*   **Platform:** Responsive HTML/CSS with a shared design system.
*   **Interactivity:** Subtle motion, scroll-triggered reveals, and cinematic lighting effects.
*   **Assets:** Custom logo marks (NotableBIT silhouettes), high-fidelity product previews, and intentional, dignified photography.
