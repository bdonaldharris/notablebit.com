---
name: NotableBIT Studio
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c2c6d8'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8c90a1'
  outline-variant: '#424656'
  surface-tint: '#b3c5ff'
  primary: '#b3c5ff'
  on-primary: '#002b75'
  primary-container: '#0066ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#0054d6'
  secondary: '#c3c0ff'
  on-secondary: '#1e00a5'
  secondary-container: '#3008e8'
  on-secondary-container: '#b3b0ff'
  tertiary: '#ffba20'
  on-tertiary: '#412d00'
  tertiary-container: '#956a00'
  on-tertiary-container: '#fff6ee'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#2e00e5'
  tertiary-fixed: '#ffdea8'
  tertiary-fixed-dim: '#ffba20'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4200'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  midnight-navy: '#0A0E1A'
  charcoal-surface: '#1A1D23'
  stroke-soft: rgba(255, 255, 255, 0.08)
  glow-blue: rgba(0, 102, 255, 0.4)
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '800'
    lineHeight: 80px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  technical-sm:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system is engineered for a premium technology studio, prioritizing strategic depth over decorative flair. The brand personality is builder-centric, cinematic, and authoritative, evoking the feeling of a high-end mission control center for founders. 

The aesthetic blends **Modern Corporate** precision with **Glassmorphism** and **Tactile** technical elements. It utilizes a deep, dark canvas to allow "Electric" accents to provide functional guidance rather than just decoration. The interface is characterized by generous whitespace, an editorial layout hierarchy, and a focus on technical clarity, ensuring the studio's strategic output remains the primary focus.

## Colors

The palette is anchored in a three-tier dark architecture. The base background is a near-absolute black (`#050505`), with Midnight Navy and Charcoal used for structural surfaces and depth layering. 

- **Primary (Electric Blue):** Reserved exclusively for high-priority actions, critical wayfinding, and active states.
- **Secondary (Muted Violet):** Used for background glows, secondary button borders, and decorative accents that imply technical sophistication.
- **Tertiary (Warm Amber):** Employed sparingly for status badges, "Beta" indicators, or highlight moments within technical documentation.
- **Neutrals:** Grays are derived from the Midnight Navy hue to maintain a cohesive, "cold" technical feel, avoiding muddy neutrals.

## Typography

The typography system relies on **Inter** for its systematic, neutral, and highly legible characteristics. Headlines use tight letter-spacing and heavy weights to create an editorial, "premium tech" impact. 

**JetBrains Mono** is introduced as a functional accent. It should be used for metadata, status labels, code snippets, and workflow steps to reinforce the "builder" identity of the studio. Large display type should often be paired with subtle gradient masks (from White to 70% White) to add cinematic depth.

## Layout & Spacing

This design system uses a **12-column fluid grid** with a fixed maximum width for content containers. The spacing rhythm is based on an 8px base unit.

- **Editorial White Space:** Sections should be separated by significant vertical padding (often 120px to 160px) to allow the content to "breathe" and signal strategic importance.
- **Asymmetric Layouts:** Use offset columns for case studies or "Orbital" diagrams to avoid a generic SaaS appearance.
- **Desktop:** 12 columns, 32px gutters, 64px margins.
- **Tablet:** 8 columns, 24px gutters, 40px margins.
- **Mobile:** 4 columns, 16px gutters, 20px margins.

## Elevation & Depth

Hierarchy is established through **tonal stacking** and **glassmorphism** rather than traditional drop shadows.

1.  **Floor:** The base background (`#050505`).
2.  **Surface:** Midnight Navy cards with a 1px `stroke-soft` border.
3.  **Elevated:** Glassmorphic layers with a 12px backdrop blur, semi-transparent charcoal fills, and subtle "glowing" top-left borders.
4.  **Interactive:** Components "lift" using a soft primary color outer glow (`glow-blue`) instead of black shadows, creating a luminous, high-tech effect.

Technical diagrams and "Orbital maps" should use thin, low-opacity concentric lines to suggest depth and connectivity without cluttering the UI.

## Shapes

The shape language is **Soft-Geometric**. A subtle radius of `4px` to `8px` is applied to most components to maintain a professional, architectural feel. 

Buttons and input fields should strictly follow the `rounded-sm` (4px) or `rounded-md` (8px) rules. Circular shapes are reserved exclusively for "orbital" nodes or profile avatars. Avoid pill-shaped buttons as they lean too "consumer-soft" for this technical studio's direction.

## Components

- **Primary Buttons:** Solid Electric Blue with `technical-sm` uppercase text. No icons unless they indicate a technical action (e.g., a terminal caret or arrow).
- **Premium Cards:** Dark Charcoal background with a subtle linear gradient (top-left to bottom-right). Borders are 1px solid `stroke-soft` with a hover state that activates a primary-colored glow.
- **Technical Chips:** Using JetBrains Mono, these feature a dark background and a border matching the accent color (Violet or Amber).
- **Timeline Motifs:** Used for roadmap or strategy sections. Use a 1px vertical line with "nodes" that glow when active.
- **Input Fields:** Minimalist design with only a bottom border in the default state, expanding to a full outlined box in the focused state with a subtle Electric Blue inner shadow.
- **Orbital Maps:** A specialized component for displaying service ecosystems, using thin circular strokes and icon nodes at the intersections.