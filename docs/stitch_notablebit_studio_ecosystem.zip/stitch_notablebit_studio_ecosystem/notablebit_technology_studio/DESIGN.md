---
name: NotableBIT Technology Studio
colors:
  surface: '#10131c'
  surface-dim: '#10131c'
  surface-bright: '#363943'
  surface-container-lowest: '#0b0e16'
  surface-container-low: '#191b24'
  surface-container: '#1d1f28'
  surface-container-high: '#272a33'
  surface-container-highest: '#32343e'
  on-surface: '#e1e2ee'
  on-surface-variant: '#c2c6d8'
  inverse-surface: '#e1e2ee'
  inverse-on-surface: '#2e303a'
  outline: '#8c90a1'
  outline-variant: '#424656'
  surface-tint: '#b3c5ff'
  primary: '#b3c5ff'
  on-primary: '#002b75'
  primary-container: '#0066ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#0054d6'
  secondary: '#ddb7ff'
  on-secondary: '#4a0080'
  secondary-container: '#622599'
  on-secondary-container: '#d1a1ff'
  tertiary: '#fbbc00'
  on-tertiary: '#402d00'
  tertiary-container: '#926c00'
  on-tertiary-container: '#fff7ee'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0050'
  on-secondary-fixed-variant: '#622599'
  tertiary-fixed: '#ffdfa0'
  tertiary-fixed-dim: '#fbbc00'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#10131c'
  on-background: '#e1e2ee'
  surface-variant: '#32343e'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  technical-label:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 24px
  section-gap: 120px
---

## Brand & Style

This design system embodies the "Strategic Cinematic" aesthetic—a blend of high-end editorial precision and deep-space technological intrigue. It is designed to feel like a command center for innovation, moving away from generic SaaS "flatness" toward a more grounded, tactile, and premium digital environment. 

The visual narrative focuses on the transition from **Idea to Execution**. This is achieved through high-contrast compositions, expansive whitespace (balanced by deep dark surfaces), and technical motifs like orbital paths and node-based connectivity. The atmosphere is intellectual, professional, and authoritative.

**Design Pillars:**
- **Cinematic Lighting:** Use of directed glows and focal highlights to draw the eye to key CTAs.
- **Precision Engineering:** Sharp geometric alignments and subtle monospaced accents that evoke a "developer-first" but "executive-ready" mindset.
- **Architectural Depth:** Tiers of information are separated by subtle luminosity shifts rather than heavy drop shadows.

## Colors

The palette is anchored in a dual-tone dark foundation. The absolute black (`#050505`) provides the "void" for high-impact content, while the Midnight Navy (`#0A1128`) acts as the secondary surface for cards and nested containers.

- **Electric Blue (#0066FF):** Used for primary actions and active states. It represents the "spark" of innovation.
- **Muted Violet (#4B0082):** Used for secondary depth, linear gradients, and decorative network lines. It adds a sophisticated, cinematic layer to the UI.
- **Warm Amber (#FFBF00):** Reserved for high-value highlights, success states, or critical data points. Use sparingly to maintain its premium "gold standard" impact.
- **Typography:** Soft White is used for headings to maximize contrast without the harshness of pure white; Cool Gray handles secondary metadata and body descriptions.

## Typography

The typography system relies on **Inter** for its systematic clarity and neutral-yet-modern footprint. To differentiate from standard corporate styles, we utilize aggressive scale (Display LG) and tight letter-spacing on headings to create an editorial, "cinematic" feel.

**JetBrains Mono** is introduced as a functional accent. It should be used for:
- Workflow labels (e.g., "STATUS: DEPLOYED")
- Data coordinates or timestamps
- Subtle "breadcrumb" navigation or technical metadata

All headlines should prioritize a "strong editorial hierarchy"—this means significant contrast between the H1 and H2, ensuring the "Move from idea to execution" messaging is the undeniable focal point.

## Layout & Spacing

The layout philosophy is built on a **12-column Fixed Grid** for desktop to maintain strict editorial control over content positioning. 

- **Generous Breathing Room:** Sections are separated by large vertical gaps (`120px+`) to allow the deep-black background to create a sense of scale and importance.
- **Desktop:** 12 columns | 32px gutters | 64px side margins.
- **Tablet:** 8 columns | 24px gutters | 40px side margins.
- **Mobile:** 4 columns | 16px gutters | 24px side margins.

Content should often be centered or "staggered" to mimic the feel of an orbital map, breaking the rigidity of standard 50/50 splits.

## Elevation & Depth

In this design system, depth is communicated through **Luminosity Layers** rather than physical shadows.

1.  **Base Layer (#050505):** The deepest level, used for the main background.
2.  **Surface Layer (#0A1128):** Used for cards and containers. These surfaces should have a 1px border using a low-opacity Electric Blue or Muted Violet to "catch the light."
3.  **Accent Glows:** Primary components may feature a subtle "Backdrop Blur" or a soft blue radial gradient behind them (15% opacity) to simulate a cinematic backlight.
4.  **Glassmorphism:** Navigation bars and floating overlays use a high-blur backdrop filter (20px+) with a 10% white fill to maintain legibility over complex background motifs.

## Shapes

To maintain the "Grounded & Strategic" personality, the shape language is sharp and disciplined. 

- **Standard Radius:** 4px (Soft) for most components (buttons, input fields).
- **Card Radius:** 8px for larger containers to provide a subtle structural softening.
- **Geometric Motifs:** Use 45-degree angled lines and perfect circles for "orbital" background decorations. 
- **Icons:** Use thin-stroke (1.5px) geometric icons. Avoid filled or rounded/bubbly icon sets.

## Components

### Buttons
- **Primary:** Solid Electric Blue with Soft White text. High-contrast. No border.
- **Secondary:** Transparent background with a 1px border of Muted Violet. 
- **Tertiary:** Text-only in JetBrains Mono with a "node" icon prefix.

### Cards
- Background: Midnight Navy (`#0A1128`).
- Border: 1px solid at 20% opacity of the Primary Color.
- Interior: Generous padding (32px or 40px) to ensure a premium feel.

### Input Fields
- Dark background (darker than the card surface).
- 1px bottom-border only for a "technical terminal" look, or a full 4px rounded border for more complex forms.
- Focus State: Border color transitions to Electric Blue with a subtle outer glow.

### Technical Motifs
- **Connected Nodes:** Use thin lines (0.5px) connecting card corners or section headers to simulate a network.
- **Orbital Maps:** Large, low-opacity concentric circles positioned in the background to add "cinematic" scale.

### Lists
- Use monospaced numbers (JetBrains Mono) for ordered lists to emphasize the "Execution" and "Step-by-step" nature of the studio.